#include "global.h"
#include "stream.h"
#include "cli.h"
#include "hash_table.h"
#include "packet.h"
#include "receiver.h"
#include "handler.h"

/**
 * ## Use
 * 
 * Initialized the receiver.
 * 
 * I could describe all that it does but I'm feeling lazy today.
 * You just gotta read main.c, sorry :-p
 * 
 */
int main(int argc, char *argv[]);