#include <CUnit/CUnit.h>


void test_receiver();

int add_receiver_tests();