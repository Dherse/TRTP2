#include <CUnit/CUnit.h>

#include "../../headers/stream.h"

void test_single();

void test_many();

int add_stream_tests();