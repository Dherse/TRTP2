#include <CUnit/CUnit.h>

void test_global();

int add_global_tests();