#include <CUnit/CUnit.h>

#include "../../headers/cli.h"

void test_cli_noopt();

void test_cli_all_opt();

int add_cli_tests();