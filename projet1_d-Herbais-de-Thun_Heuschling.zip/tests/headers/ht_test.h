
#include <CUnit/CUnit.h>

#include "../../headers/hash_table.h"
#include "../../headers/client.h"

#define N 1024

void test_ht_put_and_get();

int add_ht_tests();