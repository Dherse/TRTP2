#include <CUnit/CUnit.h>

#include "../../headers/packet.h"

void test_ack_decoding();

void test_ack_encoding();

void test_data_decoding();

void test_data_encoding();

int add_packet_tests();