#include <CUnit/CUnit.h>
#include "../../headers/buffer.h"

void test_fill_and_empty();

int add_buffer_tests();